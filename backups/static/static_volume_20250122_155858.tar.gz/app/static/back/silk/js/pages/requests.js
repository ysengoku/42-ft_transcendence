$(document).ready(function () {
    initFilters();
    initFilterButton();
});
